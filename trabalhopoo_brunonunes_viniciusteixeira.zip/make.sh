# javac CRUD.java
# javac Setor.java
# javac Item.java
# javac Pessoa.java
# javac Cliente.java
# javac Caixa.java
# javac CaixaRapido.java
# javac Funcionario.java
# javac AtendenteCaixa.java
# javac Gerente.java
# javac Produto.java
# javac Supermercado.java
javac AplicacaoSupermercado.java

java AplicacaoSupermercado