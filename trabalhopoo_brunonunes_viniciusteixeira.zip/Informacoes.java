public interface Informacoes{
	public abstract String getInfo();
}